=====
ZAVS
=====

ZAVS is the draft for better "z" antivirus corporate server.

Quick start
-----------

1. Please test zavsmodel.py as draft for server part.  
