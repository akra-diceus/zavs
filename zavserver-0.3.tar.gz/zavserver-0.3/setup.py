import os
from setuptools import find_packages, setup

with open(os.path.join(os.path.dirname(__file__), 'README.rst')) as readme:
    README = readme.read()

os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), os.pardir)))

setup(
    name='zavserver',
    version='0.3',
    packages=find_packages(),
    include_package_data=True,
    license='GNU General Public License v3.0',
    description='ZAVS is the draft for better "z" antivirus corporate server.',
    long_description=README,
    url='https://github.com/svetkesh/zavs/',
    author='Arkadii Kravchenko',
    author_email='svetkesh@hotmail.com',
    classifiers=[
        'Environment :: Web Environment',
        'Framework :: sqlalchemy',
        'Framework :: sqlalchemy :: 1.2',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: GNU General Public License v3.0',  # example license
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.5',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Internet :: WWW/HTTP :: Dynamic Content',
    ],
)
